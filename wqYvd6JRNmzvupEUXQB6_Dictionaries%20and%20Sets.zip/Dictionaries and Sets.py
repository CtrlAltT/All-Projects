"""This file ofer you information about my favourite`s Michael Jackson`s discography and about his personal life"""

def all_in_one(information):


    information = {"artist":"Michael Joseph Jackson","born_year":"29.08.1958","age":50,"occupation":"singer,song writer",
               "spouse":"Lisa Marie Presley",
               "children":"Michael Junior, Paris,Prince Michael 2",
               "name_of_concert":"Dangerous tour",
               "song":"Billie Jean","peak_chart_position":1,
               "country":"US","name_of_concert":"Dangerous tour",
               "location":"Bucharest","year":1992,"lenght_in_minutes":121.58}
    return information

print(all_in_one({}))

