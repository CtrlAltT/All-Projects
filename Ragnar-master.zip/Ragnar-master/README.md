# Ragnar

The purpose of this files are only for study. 
