def hello_world():
  print ("Hello, world!")
hello_world()