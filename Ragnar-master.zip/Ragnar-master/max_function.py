def max_function(x,y):
    if x >=y:
        return x
    elif y>=x:
        return y
print(max_function(4,5))